INSERT INTO auco_test.domains (domain_name) VALUES
	 ('acting'),
	 ('culture'),
	 ('misc'),
	 ('politics'),
	 ('science'),
	 ('sport');
