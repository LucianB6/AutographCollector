INSERT INTO auco_test.users (name,uname,email,phone,password,registerDate,profilePicture) VALUES
	 ('Verif Nume','big1234','big1234@ab.cd','0777777777','$2y$10$Yuwk/b..sPPY7kwP69Yj1.9ghEpXEOlphnIUMRdXU0wiNNH1c4d/S',NULL,'/images/profile/default.jpg'),
	 ('verifnume','verifnume','verifnume@gma.cl','0784392459','$2y$10$V6yFSkPpCCZKFpp9LgK//um6n9FGHqG2odPKas6n1dSKOC3vNucZi',NULL,'/images/profile/verif.jpg'),
	 ('verifnumeabc','verifnume2','verifnume2@gma.cl','0784392458','$2y$10$qkkS/OvR5x54U.pK4PQwPep2JbRAtNvc9pzQaqNaCSa1WfqfijM.G',NULL,'/images/profile/default.jpg'),
	 ('verifnumeabcd','verifnume3','verifnume3@gma.cl','0784392457','$2y$10$sJKvbkVWBoXszS.W12re0eehw5n7bStHNjep9iUhQ3JfDk6QX4wra',NULL,'/images/profile/default.jpg'),
	 ('verifnumeabcde','verifnume4','verifnume4@gma.cl','0784392456','$2y$10$e2IbgWjSmOIbayD6oSQneuCDWKbssjwhUz.uOXd5yWg.O8k7Y/ypO',NULL,'/images/profile/default.jpg');
