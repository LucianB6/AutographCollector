
**IMPORTANT**
1. numele bazei de date e auco_test
2. creare tabele in ordinea asta ca sa nu fie probleme cu foreign keys:
    -users
    -celebrities
    -domains
    -celebrityDomain
    -catalog
3. popularea tabelelor/restul in aceeasi ordine ca mai sus:
  *catalog lipseste pt. ca e momentan gol*
    -users
    -celebrities
    -domains
    -celebrityDomain


FOLDERE:
1. TABLES
    fisiere .sql pt crearea tabelelor cu constraint-uri, forein keys, etc.

2. DATA
    fisiere .sql pt popularea tabelelor cu date
